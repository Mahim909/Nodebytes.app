package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.viewinterop.AndroidView
import com.brightdata.sdk.BrightData
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  private var webViewInstance: WebView? = null

  companion object {
    const val BRIGHT_SDK_APP_KEY = "com.mahimgfx.nodebytes"
    var instance: MainActivity? = null
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    instance = this
    enableEdgeToEdge()

    // Bright SDK Initialization with Event Callback
    initBrightSDK()

    setContent {
      MyApplicationTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
          NodeBytesWebView(
            activity = this,
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding),
            onWebViewCreated = { webViewInstance = it },
            onDataSend = { bytes -> sendDataToJS(bytes) }
          )
        }
      }
    }
  }

  fun initializeBrightSDK(onConsentResult: ((Boolean) -> Unit)? = null) {
    runOnUiThread {
      if (!BrightData.isOptIn(this)) {
        BrightData.showConsentDialog(this, object : BrightData.ConsentListener {
          override fun onConsentGiven() {
            checkAndRequestAllPermissions()
            startNodeBytesService()
            onConsentResult?.invoke(true)
            notifyConsentState(true)
          }

          override fun onConsentDeclined() {
            Toast.makeText(this@MainActivity, "Bandwidth sharing consent declined.", Toast.LENGTH_SHORT).show()
            onConsentResult?.invoke(false)
            notifyConsentState(false)
          }
        })
      } else {
        checkAndRequestAllPermissions()
        startNodeBytesService()
        onConsentResult?.invoke(true)
        notifyConsentState(true)
      }
    }
  }

  fun startNodeBytesService() {
    try {
      val serviceIntent = Intent(this, NodeBytesService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(serviceIntent)
      } else {
        startService(serviceIntent)
      }
      Toast.makeText(this, "NodeBytes: Bandwidth Sharing Active", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun stopNodeBytesService() {
    try {
      val serviceIntent = Intent(this, NodeBytesService::class.java)
      stopService(serviceIntent)
      Toast.makeText(this, "NodeBytes: Stopped / Standby", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  private fun notifyConsentState(consented: Boolean) {
    webViewInstance?.evaluateJavascript(
      "javascript:if(window.onConsentUpdated){ window.onConsentUpdated($consented); }",
      null
    )
  }

  fun checkAndRequestAllPermissions() {
    // 1. Notification Permission (Android 13+ / API 33+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
      }
    }

    // 2. Battery Optimization Ignore Dialog (Android 6+ / API 23+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      try {
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (powerManager != null && !powerManager.isIgnoringBatteryOptimizations(packageName)) {
          val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$packageName")
          }
          startActivity(intent)
        }
      } catch (e: Exception) {
        e.printStackTrace()
      }
    }
  }

  override fun onDestroy() {
    if (instance == this) {
      instance = null
    }
    super.onDestroy()
  }

  private fun initBrightSDK() {
    try {
      BrightData.init(this, BRIGHT_SDK_APP_KEY, object : BrightData.Listener {
        override fun onDataTransferred(bytesTransferred: Long) {
          sendDataToJS(bytesTransferred)
        }

        override fun onError(e: Exception) {
          e.printStackTrace()
        }
      })
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun sendDataToJS(bytesTransferred: Long) {
    runOnUiThread {
      webViewInstance?.evaluateJavascript(
        "javascript:if(window.onSDKDataTransferred){ window.onSDKDataTransferred($bytesTransferred); }",
        null
      )
    }
  }

  @Deprecated("Deprecated in Java")
  override fun onBackPressed() {
    if (webViewInstance?.canGoBack() == true) {
      webViewInstance?.goBack()
    } else {
      super.onBackPressed()
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun NodeBytesWebView(
  activity: MainActivity,
  modifier: Modifier = Modifier,
  onWebViewCreated: (WebView) -> Unit = {},
  onDataSend: (Long) -> Unit = {}
) {
  AndroidView(
    modifier = modifier,
    factory = { context ->
      WebView(context).apply {
        setBackgroundColor(android.graphics.Color.parseColor("#020617"))
        try {
          setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        } catch (e: Exception) {
          setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
        }
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
          override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val url = request?.url?.toString() ?: return false
            if (url.startsWith("https://wa.me/") || url.startsWith("whatsapp://") || url.startsWith("market://")) {
              try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
                return true
              } catch (e: Exception) {
                Toast.makeText(context, "Opening link: $url", Toast.LENGTH_SHORT).show()
                return false
              }
            }
            return false
          }
        }

        val bridge = WebAppInterface(activity) { bytes ->
          onDataSend(bytes)
        }
        // JavaScript Interface Bind: Available in JS as both "AndroidBridge" and "BrightSDK"
        addJavascriptInterface(bridge, "AndroidBridge")
        addJavascriptInterface(bridge, "BrightSDK")

        loadUrl("file:///android_asset/index.html")
        onWebViewCreated(this)
      }
    }
  )
}

/**
 * JS Bridge Interface Class
 * Exposes methods to both "AndroidBridge" and "BrightSDK" in WebView JS context.
 */
class WebAppInterface(
  private val activity: MainActivity,
  private val onDataTransferred: (Long) -> Unit
) {
  private val handler = Handler(Looper.getMainLooper())

  @JavascriptInterface
  fun startBrightSDK() {
    handler.post {
      activity.initializeBrightSDK()
    }
  }

  @JavascriptInterface
  fun stopBrightSDK() {
    handler.post {
      activity.stopNodeBytesService()
    }
  }

  @JavascriptInterface
  fun isOptIn(): Boolean {
    return BrightData.isOptIn(activity)
  }

  @JavascriptInterface
  fun showConsentDialog() {
    handler.post {
      activity.initializeBrightSDK()
    }
  }

  @JavascriptInterface
  fun requestPermissions() {
    handler.post {
      activity.checkAndRequestAllPermissions()
    }
  }

  @JavascriptInterface
  fun start() {
    startBrightSDK()
  }

  @JavascriptInterface
  fun stop() {
    stopBrightSDK()
  }

  @JavascriptInterface
  fun isSDKActive(): Boolean = BrightData.isRunning()

  @JavascriptInterface
  fun triggerSDKDataTransfer(bytes: Long) {
    handler.post {
      BrightData.notifyDataTransferred(bytes)
      onDataTransferred(bytes)
    }
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  MyApplicationTheme { Greeting("Android") }
}

