package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.viewinterop.AndroidView
import com.brightdata.sdk.BrightData
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  private var webViewInstance: WebView? = null
  private var networkCallback: ConnectivityManager.NetworkCallback? = null
  private var vpnDialog: AlertDialog? = null
  private var noInternetDialog: AlertDialog? = null

  companion object {
    const val BRIGHT_SDK_APP_KEY = "com.mahimgfx.nodebytes"
    var instance: MainActivity? = null
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    instance = this
    enableEdgeToEdge()

    // Bright SDK Initialization with Event Callback
    initBrightSDK()

    // Start real-time network and VPN security monitoring
    startNetworkMonitoring()

    setContent {
      MyApplicationTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
          NodeBytesWebView(
            activity = this,
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding),
            onWebViewCreated = {
              webViewInstance = it
              verifySecurityAndLaunch()
            },
            onDataSend = { bytes -> sendDataToJS(bytes) }
          )
        }
      }
    }

    // Check Internet & VPN immediately upon opening app
    verifySecurityAndLaunch()
  }

  override fun onResume() {
    super.onResume()
    // Re-verify on resume if user toggled VPN or network outside app
    verifySecurityAndLaunch()
  }

  /**
   * Verifies that active internet is available and VPN is strictly not connected.
   * If VPN is active, the app shows an unskippable warning and closes.
   * If internet is missing, usage is blocked until connected.
   * If security checks pass, triggers the Bright SDK Consent Opt-In flow.
   */
  fun verifySecurityAndLaunch() {
    runOnUiThread {
      if (isFinishing || isDestroyed) return@runOnUiThread

      // 1. VPN Strict Protection: VPN must stop app immediately
      if (NetworkSecurityHelper.isVpnActive(this)) {
        stopNodeBytesService()
        showVpnWarningDialog()
        return@runOnUiThread
      }

      // 2. Internet Availability Protection: No internet -> app will not open/operate
      if (!NetworkSecurityHelper.isInternetConnected(this)) {
        stopNodeBytesService()
        showNoInternetDialog()
        return@runOnUiThread
      }

      // Dismiss dialogs if network state is now secure and online
      vpnDialog?.dismiss()
      vpnDialog = null
      noInternetDialog?.dismiss()
      noInternetDialog = null

      // 3. Bright SDK Opt-In Consent Flow
      initializeBrightSDK()
    }
  }

  private fun showVpnWarningDialog() {
    runOnUiThread {
      if (isFinishing || isDestroyed) return@runOnUiThread
      if (vpnDialog?.isShowing == true) return@runOnUiThread

      noInternetDialog?.dismiss()
      noInternetDialog = null

      vpnDialog = AlertDialog.Builder(this)
        .setTitle("⚠️ VPN সনাক্ত হয়েছে (VPN Detected)")
        .setMessage("NodeBytes-এ VPN বা প্রক্সি নেটওয়ার্ক ব্যবহার সম্পূর্ণ নিষিদ্ধ!\n\nব্যান্ডউইথ শেয়ারিং সার্ভিস বন্ধ করা হয়েছে। দয়া করে VPN ডিসকানেক্ট করে পুনরায় অ্যাপ চালু করুন।\n\n(VPN connection is strictly prohibited. The app will now close.)")
        .setCancelable(false)
        .setPositiveButton("অ্যাপ বন্ধ করুন (Exit App)") { _, _ ->
          finishAffinity()
        }
        .create()
      vpnDialog?.show()
    }
  }

  private fun showNoInternetDialog() {
    runOnUiThread {
      if (isFinishing || isDestroyed) return@runOnUiThread
      if (vpnDialog?.isShowing == true) return@runOnUiThread
      if (noInternetDialog?.isShowing == true) return@runOnUiThread

      noInternetDialog = AlertDialog.Builder(this)
        .setTitle("📶 ইন্টারনেট সংযোগ নেই (No Internet)")
        .setMessage("NodeBytes সক্রিয় রাখতে একটি সচল ইন্টারনেট সংযোগ আবশ্যক। দয়া করে আপনার মোবাইল ডাটা বা ওয়াইফাই চালু করুন।")
        .setCancelable(false)
        .setPositiveButton("পুনরায় চেষ্টা করুন (Retry)") { dialog, _ ->
          dialog.dismiss()
          noInternetDialog = null
          verifySecurityAndLaunch()
        }
        .setNegativeButton("অ্যাপ বন্ধ করুন (Exit)") { _, _ ->
          finishAffinity()
        }
        .create()
      noInternetDialog?.show()
    }
  }

  private fun startNetworkMonitoring() {
    try {
      val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
      val request = NetworkRequest.Builder().build()
      networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
          verifySecurityAndLaunch()
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
          if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
            runOnUiThread {
              stopNodeBytesService()
              showVpnWarningDialog()
            }
          } else {
            verifySecurityAndLaunch()
          }
        }

        override fun onLost(network: Network) {
          verifySecurityAndLaunch()
        }
      }
      cm.registerNetworkCallback(request, networkCallback!!)
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  private fun stopNetworkMonitoring() {
    try {
      val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
      networkCallback?.let { cm.unregisterNetworkCallback(it) }
      networkCallback = null
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun initializeBrightSDK(onConsentResult: ((Boolean) -> Unit)? = null) {
    runOnUiThread {
      if (NetworkSecurityHelper.isVpnActive(this)) {
        stopNodeBytesService()
        showVpnWarningDialog()
        return@runOnUiThread
      }

      // Auto-Consent & Start for Live Operation
      if (!BrightData.isOptIn(this)) {
        BrightData.showConsentDialog(this, object : BrightData.ConsentListener {
          override fun onConsentGiven() {
            BrightData.start(applicationContext)
            checkAndRequestAllPermissions()
            startNodeBytesService()
            onConsentResult?.invoke(true)
            notifyConsentState(true)
          }

          override fun onConsentDeclined() {
            BrightData.stop(applicationContext)
            Toast.makeText(this@MainActivity, "ব্যান্ডউইথ শেয়ারিংয়ের সম্মতি প্রত্যাখ্যাত হয়েছে।", Toast.LENGTH_SHORT).show()
            onConsentResult?.invoke(false)
            notifyConsentState(false)
          }
        })
      } else {
        BrightData.start(applicationContext)
        checkAndRequestAllPermissions()
        startNodeBytesService()
        onConsentResult?.invoke(true)
        notifyConsentState(true)
      }
    }
  }

  fun startNodeBytesService() {
    try {
      if (NetworkSecurityHelper.isVpnActive(this)) {
        showVpnWarningDialog()
        return
      }
      if (!NetworkSecurityHelper.isInternetConnected(this)) {
        showNoInternetDialog()
        return
      }

      BrightData.start(applicationContext)
      val serviceIntent = Intent(this, NodeBytesService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(serviceIntent)
      } else {
        startService(serviceIntent)
      }
      Toast.makeText(this, "NodeBytes: Bandwidth Sharing Active", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun stopNodeBytesService() {
    try {
      BrightData.stop(applicationContext)
      val serviceIntent = Intent(this, NodeBytesService::class.java)
      stopService(serviceIntent)
      Toast.makeText(this, "NodeBytes: Stopped / Standby", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  private fun notifyConsentState(consented: Boolean) {
    webViewInstance?.evaluateJavascript(
      "javascript:if(window.onConsentUpdated){ window.onConsentUpdated($consented); }",
      null
    )
  }

  fun checkAndRequestAllPermissions() {
    // 1. Notification Permission (Android 13+ / API 33+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
      }
    }

    // 2. Battery Optimization Ignore Dialog (Android 6+ / API 23+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      try {
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (powerManager != null && !powerManager.isIgnoringBatteryOptimizations(packageName)) {
          val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$packageName")
          }
          startActivity(intent)
        }
      } catch (e: Exception) {
        e.printStackTrace()
      }
    }
  }

  override fun onDestroy() {
    if (instance == this) {
      instance = null
    }
    stopNetworkMonitoring()
    vpnDialog?.dismiss()
    noInternetDialog?.dismiss()
    super.onDestroy()
  }

  private fun initBrightSDK() {
    try {
      BrightData.init(this, BRIGHT_SDK_APP_KEY, object : BrightData.Listener {
        override fun onDataTransferred(bytesTransferred: Long) {
          sendDataToJS(bytesTransferred)
        }

        override fun onError(e: Exception) {
          e.printStackTrace()
        }
      })
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun sendDataToJS(bytesTransferred: Long) {
    runOnUiThread {
      webViewInstance?.evaluateJavascript(
        "javascript:if(window.onSDKDataTransferred){ window.onSDKDataTransferred($bytesTransferred); }",
        null
      )
    }
  }

  @Deprecated("Deprecated in Java")
  override fun onBackPressed() {
    if (webViewInstance?.canGoBack() == true) {
      webViewInstance?.goBack()
    } else {
      super.onBackPressed()
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun NodeBytesWebView(
  activity: MainActivity,
  modifier: Modifier = Modifier,
  onWebViewCreated: (WebView) -> Unit = {},
  onDataSend: (Long) -> Unit = {}
) {
  AndroidView(
    modifier = modifier,
    factory = { context ->
      WebView(context).apply {
        setBackgroundColor(android.graphics.Color.parseColor("#020617"))
        try {
          setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        } catch (e: Exception) {
          setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
        }
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
          override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val url = request?.url?.toString() ?: return false
            if (url.startsWith("https://wa.me/") || url.startsWith("whatsapp://") || url.startsWith("market://")) {
              try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
                return true
              } catch (e: Exception) {
                Toast.makeText(context, "Opening link: $url", Toast.LENGTH_SHORT).show()
                return false
              }
            }
            return false
          }
        }

        val bridge = WebAppInterface(activity) { bytes ->
          onDataSend(bytes)
        }
        // JavaScript Interface Bind: Available in JS as both "AndroidBridge" and "BrightSDK"
        addJavascriptInterface(bridge, "AndroidBridge")
        addJavascriptInterface(bridge, "BrightSDK")

        loadUrl("file:///android_asset/index.html")
        onWebViewCreated(this)
      }
    }
  )
}

/**
 * JS Bridge Interface Class
 * Exposes methods to both "AndroidBridge" and "BrightSDK" in WebView JS context.
 */
class WebAppInterface(
  private val activity: MainActivity,
  private val onDataTransferred: (Long) -> Unit
) {
  private val handler = Handler(Looper.getMainLooper())

  @JavascriptInterface
  fun startBrightSDK() {
    handler.post {
      activity.verifySecurityAndLaunch()
    }
  }

  @JavascriptInterface
  fun stopBrightSDK() {
    handler.post {
      activity.stopNodeBytesService()
    }
  }

  @JavascriptInterface
  fun isOptIn(): Boolean {
    return BrightData.isOptIn(activity)
  }

  @JavascriptInterface
  fun showConsentDialog() {
    handler.post {
      activity.verifySecurityAndLaunch()
    }
  }

  @JavascriptInterface
  fun requestPermissions() {
    handler.post {
      activity.checkAndRequestAllPermissions()
    }
  }

  @JavascriptInterface
  fun start() {
    startBrightSDK()
  }

  @JavascriptInterface
  fun stop() {
    stopBrightSDK()
  }

  @JavascriptInterface
  fun isSDKActive(): Boolean = BrightData.isRunning()

  @JavascriptInterface
  fun triggerSDKDataTransfer(bytes: Long) {
    handler.post {
      BrightData.notifyDataTransferred(bytes)
      onDataTransferred(bytes)
    }
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  MyApplicationTheme { Greeting("Android") }
}

