package com.example

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import java.net.NetworkInterface
import java.util.Collections

object NetworkSecurityHelper {

  /**
   * Checks if an active internet connection exists (WiFi or Mobile Data).
   */
  fun isInternetConnected(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val activeNetwork = cm.activeNetwork ?: return false
    val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
  }

  /**
   * Detects if any VPN or proxy tunnel is currently active on the device.
   * Checks both ConnectivityManager network capabilities and physical/virtual network interfaces.
   */
  fun isVpnActive(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false

    // 1. Check active network capabilities
    try {
      val activeNetwork = cm.activeNetwork
      if (activeNetwork != null) {
        val caps = cm.getNetworkCapabilities(activeNetwork)
        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
          return true
        }
      }

      // Check all available system networks
      for (network in cm.allNetworks) {
        val caps = cm.getNetworkCapabilities(network)
        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
          return true
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }

    // 2. Check network interface names for known VPN tunnels (tun, tap, ppp, ipsec, wg, etc.)
    try {
      val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
      for (intf in interfaces) {
        if (!intf.isUp || intf.interfaceAddresses.isEmpty()) continue
        val name = intf.name.lowercase()
        if (name.startsWith("tun") || 
            name.startsWith("tap") || 
            name.startsWith("ppp") || 
            name.startsWith("p2p") || 
            name.startsWith("ipsec") ||
            name.startsWith("wg") ||
            name.contains("vpn")) {
          return true
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }

    return false
  }
}
