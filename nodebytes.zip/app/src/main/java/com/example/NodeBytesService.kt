package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.brightdata.sdk.BrightData

class NodeBytesService : Service() {

  companion object {
    private const val CHANNEL_ID = "NodeBytesServiceChannel"
    private const val NOTIFICATION_ID = 101
  }

  override fun onCreate() {
    super.onCreate()
    createNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("NodeBytes Network Active")
      .setContentText("Sharing bandwidth in background to earn rewards...")
      .setSmallIcon(R.mipmap.ic_launcher)
      .setOngoing(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .build()

    // Android 14+ (API 34+) compatibility for dataSync foreground service type
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }

    // Bright SDK activation with listener
    try {
      BrightData.init(this, MainActivity.BRIGHT_SDK_APP_KEY, object : BrightData.Listener {
        override fun onDataTransferred(bytesTransferred: Long) {
          MainActivity.instance?.sendDataToJS(bytesTransferred)
        }

        override fun onError(e: Exception) {
          e.printStackTrace()
        }
      })
      BrightData.start(applicationContext)
    } catch (e: Exception) {
      e.printStackTrace()
    }

    return START_STICKY
  }

  override fun onDestroy() {
    // When service stops, stop Bright SDK
    try {
      BrightData.stop(applicationContext)
    } catch (e: Exception) {
      e.printStackTrace()
    }
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val serviceChannel = NotificationChannel(
        CHANNEL_ID,
        "NodeBytes Background Service",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Monitors background bandwidth sharing status"
      }
      val manager = getSystemService(NotificationManager::class.java)
      manager?.createNotificationChannel(serviceChannel)
    }
  }
}
