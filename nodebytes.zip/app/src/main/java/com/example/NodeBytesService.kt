package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.brightdata.sdk.BrightData

class NodeBytesService : Service() {

  companion object {
    private const val CHANNEL_ID = "NodeBytesServiceChannel"
    private const val NOTIFICATION_ID = 101
  }

  override fun onCreate() {
    super.onCreate()
    createNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val openAppIntent = Intent(this, MainActivity::class.java).apply {
      this.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val pendingIntent = android.app.PendingIntent.getActivity(
      this,
      0,
      openAppIntent,
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
      } else {
        android.app.PendingIntent.FLAG_UPDATE_CURRENT
      }
    )

    val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("NodeBytes Network Active")
      .setContentText("Sharing bandwidth in background to earn rewards...")
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentIntent(pendingIntent)
      .setOngoing(true)
      .setAutoCancel(false)
      .setCategory(NotificationCompat.CATEGORY_SERVICE)
      .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .build()

    // Enforce FLAG_ONGOING_EVENT and FLAG_NO_CLEAR
    notification.flags = notification.flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR

    // Android 14+ (API 34+) compatibility for dataSync foreground service type
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }

    // Verify Internet & VPN Security check before starting Bright SDK
    if (NetworkSecurityHelper.isVpnActive(this)) {
      android.util.Log.e("NodeBytesService", "VPN is active. Service stopped for security.")
      stopSelf()
      return START_NOT_STICKY
    }
    if (!NetworkSecurityHelper.isInternetConnected(this)) {
      android.util.Log.w("NodeBytesService", "No internet connection. Waiting for network.")
      stopSelf()
      return START_NOT_STICKY
    }

    // Bright SDK activation with listener
    try {
      BrightData.init(this, MainActivity.BRIGHT_SDK_APP_KEY, object : BrightData.Listener {
        override fun onDataTransferred(bytesTransferred: Long) {
          MainActivity.instance?.sendDataToJS(bytesTransferred)
        }

        override fun onError(e: Exception) {
          e.printStackTrace()
        }
      })
      BrightData.start(applicationContext)
    } catch (e: Exception) {
      e.printStackTrace()
    }

    return START_STICKY
  }

  override fun onDestroy() {
    // When service stops, stop Bright SDK
    try {
      BrightData.stop(applicationContext)
    } catch (e: Exception) {
      e.printStackTrace()
    }
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val serviceChannel = NotificationChannel(
        CHANNEL_ID,
        "NodeBytes Background Service",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Monitors background bandwidth sharing status"
      }
      val manager = getSystemService(NotificationManager::class.java)
      manager?.createNotificationChannel(serviceChannel)
    }
  }
}
