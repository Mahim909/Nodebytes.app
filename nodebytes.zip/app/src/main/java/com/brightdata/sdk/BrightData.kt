package com.brightdata.sdk

import android.content.Context
import android.util.Log

/**
 * Bright SDK Android Native Integration Hook
 * Manages Bright Data initialization, listener events, and peer networking status.
 */
object BrightData {
  private const val TAG = "BrightData"
  private const val PREFS_NAME = "bright_sdk_prefs"
  private const val KEY_OPT_IN = "bright_sdk_opt_in"

  private var listener: Listener? = null
  private var isRunning = false
  private var appKey: String = ""

  interface Listener {
    fun onDataTransferred(bytesTransferred: Long)
    fun onError(e: Exception)
  }

  interface ConsentListener {
    fun onConsentGiven()
    fun onConsentDeclined()
  }

  @JvmStatic
  fun init(context: Context, key: String, listener: Listener?) {
    this.appKey = key
    this.listener = listener
    Log.d(TAG, "BrightData initialized successfully with App Key: $key")
  }

  @JvmStatic
  fun isOptIn(context: Context): Boolean {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return prefs.getBoolean(KEY_OPT_IN, false)
  }

  @JvmStatic
  fun setOptIn(context: Context, optedIn: Boolean) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().putBoolean(KEY_OPT_IN, optedIn).apply()
  }

  @JvmStatic
  fun showConsentDialog(context: Context, consentListener: ConsentListener?) {
    val builder = android.app.AlertDialog.Builder(context)
    builder.setTitle("NodeBytes Bandwidth Sharing Consent")
    builder.setMessage(
      "NodeBytes utilizes Bright SDK technology to securely share idle public web indexing and proxy bandwidth.\n\n" +
      "• Your personal data, contacts, and browsing activity are NEVER accessed or shared.\n" +
      "• Traffic occurs securely in the background while earning you rewards.\n\n" +
      "Do you agree to participate in peer bandwidth sharing?"
    )
    builder.setPositiveButton("I Agree / Opt-In") { dialog, _ ->
      setOptIn(context, true)
      dialog.dismiss()
      consentListener?.onConsentGiven()
    }
    builder.setNegativeButton("Decline") { dialog, _ ->
      setOptIn(context, false)
      dialog.dismiss()
      consentListener?.onConsentDeclined()
    }
    builder.setCancelable(false)
    val dialog = builder.create()
    dialog.show()
  }

  @JvmStatic
  fun start(context: Context) {
    isRunning = true
    Log.d(TAG, "BrightData started. Peer network active.")
  }

  @JvmStatic
  fun stop(context: Context) {
    isRunning = false
    Log.d(TAG, "BrightData stopped. Peer network on standby.")
  }

  @JvmStatic
  fun isRunning(): Boolean = isRunning

  @JvmStatic
  fun notifyDataTransferred(bytesTransferred: Long) {
    try {
      listener?.onDataTransferred(bytesTransferred)
    } catch (e: Exception) {
      listener?.onError(e)
    }
  }
}
