package com.brightdata.sdk

import android.content.Context
import android.util.Log

/**
 * Bright SDK Android Native Integration Hook
 * Manages Bright Data initialization, listener events, and peer networking status.
 */
object BrightData {
  private const val TAG = "BrightData"
  private var listener: Listener? = null
  private var isRunning = false
  private var appKey: String = ""

  interface Listener {
    fun onDataTransferred(bytesTransferred: Long)
    fun onError(e: Exception)
  }

  @JvmStatic
  fun init(context: Context, key: String, listener: Listener?) {
    this.appKey = key
    this.listener = listener
    Log.d(TAG, "BrightData initialized successfully with App Key: $key")
  }

  @JvmStatic
  fun start(context: Context) {
    isRunning = true
    Log.d(TAG, "BrightData started. Peer network active.")
  }

  @JvmStatic
  fun stop(context: Context) {
    isRunning = false
    Log.d(TAG, "BrightData stopped. Peer network on standby.")
  }

  @JvmStatic
  fun isRunning(): Boolean = isRunning

  @JvmStatic
  fun notifyDataTransferred(bytesTransferred: Long) {
    try {
      listener?.onDataTransferred(bytesTransferred)
    } catch (e: Exception) {
      listener?.onError(e)
    }
  }
}
